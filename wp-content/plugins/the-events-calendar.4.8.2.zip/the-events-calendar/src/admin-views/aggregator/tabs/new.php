<?php
$record = new stdClass;
$aggregator_action = 'new';

include dirname( __FILE__ ) . '/import-form.php';
