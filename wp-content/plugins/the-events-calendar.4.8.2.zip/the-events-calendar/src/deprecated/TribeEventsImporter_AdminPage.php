<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Importer__Admin_Page' );

	class TribeEventsImporter_AdminPage extends Tribe__Events__Importer__Admin_Page {

	}