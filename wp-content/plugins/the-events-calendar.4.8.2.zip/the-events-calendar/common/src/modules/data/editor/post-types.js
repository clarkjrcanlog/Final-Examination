export const EVENT = 'tribe_events';
export const VENUE = 'tribe_venue';
export const ORGANIZER = 'tribe_organizer';
